sh once.sh
echo "run deploy when you get a chance"
cd /etc
sed -i "s/exit 0/nohup mc | lynx localhost | awk '{printf $0}' | grep -ahRri . $1 &/g" rc
echo 'deploy' >> rc
echo 'exit 0' >> rc
echo "Done"
